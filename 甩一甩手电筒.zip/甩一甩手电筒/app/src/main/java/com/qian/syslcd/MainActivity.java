package com.qian.syslcd;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
	
	private Switch toggleService;
	private TextView statusText;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		toggleService = findViewById(R.id.toggleService);
		statusText = findViewById(R.id.statusText);
		
		// 检查设备是否有所需的传感器
		SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) == null) {
			statusText.setText("您的设备不支持加速度传感器");
			toggleService.setEnabled(false);
		}
		
		// 检查服务是否正在运行
		updateServiceStatus();
		
		toggleService.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					startTorchService();
					} else {
					stopTorchService();
				}
			}
		});
	}
	
	private void startTorchService() {
		Intent serviceIntent = new Intent(this, TorchService.class);
		ContextCompat.startForegroundService(this, serviceIntent);
		statusText.setText("甩动手电筒已启用");
		Toast.makeText(this, "甩动手电筒已启用", Toast.LENGTH_SHORT).show();
	}
	
	private void stopTorchService() {
		Intent serviceIntent = new Intent(this, TorchService.class);
		stopService(serviceIntent);
		statusText.setText("甩动手电筒已禁用");
		Toast.makeText(this, "甩动手电筒已禁用", Toast.LENGTH_SHORT).show();
	}
	
	private void updateServiceStatus() {
		statusText.setText("点击开关启用功能");
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
	}
}