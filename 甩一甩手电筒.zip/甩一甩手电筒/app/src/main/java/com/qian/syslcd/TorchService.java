package com.qian.syslcd;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class TorchService extends Service implements SensorEventListener {
	
	private static final String CHANNEL_ID = "ShakeTorchChannel";
	private static final int NOTIFICATION_ID = 1;
	
	private SensorManager sensorManager;
	private Sensor accelerometer;
	private CameraManager cameraManager;
	private String cameraId;
	private Vibrator vibrator;
	
	// 甩动检测变量
	private long lastShakeTime;
	private int shakeCount;
	private static final int SHAKE_SLOP_TIME_MS = 1000;
	private static final int SHAKE_COUNT = 2;
	private static final float SHAKE_THRESHOLD = 30.0f;
	private boolean isTorchOn = false;
	
	@Override
	public void onCreate() {
		super.onCreate();
		
		sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
		vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		
		// 寻找后置摄像头
		try {	
			for (String id : cameraManager.getCameraIdList()) {
				CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(id);
				Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
				if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
					cameraId = id;
					break;
				}
			}
			} catch (CameraAccessException e) {
			e.printStackTrace();
		}
		
		// 创建通知渠道
		createNotificationChannel();
		
		// 启动前台服务
		startForeground(NOTIFICATION_ID, createNotification());
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// 注册传感器监听器
		if (accelerometer != null) {
			sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
		}
		
		return START_STICKY;
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		// 取消传感器监听
		sensorManager.unregisterListener(this);
		// 确保手电筒关闭
		setTorch(false);
	}
	
	@Nullable
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	@Override
	public void onSensorChanged(SensorEvent event) {
		if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
			float x = event.values[0];
			float y = event.values[1];
			float z = event.values[2];
			
			double acceleration = Math.sqrt(x * x + y * y + z * z) - SensorManager.GRAVITY_EARTH;
			
			if (acceleration > SHAKE_THRESHOLD) {
				long currentTime = System.currentTimeMillis();
				
				if (shakeCount == 0) {
					shakeCount++;
					lastShakeTime = currentTime;
					} else {
					if (currentTime - lastShakeTime < SHAKE_SLOP_TIME_MS) {
						shakeCount++;
						} else {
						shakeCount = 1;
						lastShakeTime = currentTime;
					}
					
					if (shakeCount == SHAKE_COUNT) {
						toggleTorch();
						shakeCount = 0;
					}
				}
			}
		}
	}
	
	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		
	}
	
	private void toggleTorch() {
		isTorchOn = !isTorchOn;
		setTorch(isTorchOn);
		
		// 震动反馈
		if (vibrator != null && vibrator.hasVibrator()) {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
				vibrator.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE));
				} else {
				vibrator.vibrate(100);
			}
		}
	}
	
	private void setTorch(boolean enabled) {
		try {
			if (cameraId != null) {
				cameraManager.setTorchMode(cameraId, enabled);
			}
			} catch (CameraAccessException e) {
			e.printStackTrace();
		}
	}
	
	private void createNotificationChannel() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			NotificationChannel serviceChannel = new NotificationChannel(
			CHANNEL_ID,
			"手电筒服务",
			NotificationManager.IMPORTANCE_DEFAULT
			);
			
			NotificationManager manager = getSystemService(NotificationManager.class);
			if (manager != null) {
				manager.createNotificationChannel(serviceChannel);
			}
		}
	}
	
	private Notification createNotification() {
		return new NotificationCompat.Builder(this, CHANNEL_ID)
		.setContentTitle("甩一甩手电筒")
		.setContentText("服务正在运行中")
		.setSmallIcon(R.drawable.ic_launcher_background)
		.build();
	}
}